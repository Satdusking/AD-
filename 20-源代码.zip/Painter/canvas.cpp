﻿#include "canvas.h"

#include <QKeyEvent>
#include <QMouseEvent>
#include <QPainter>

#include "textInputBox.h"

Canvas::Canvas(QWidget* parent) :
    QWidget(parent)
{
    this->setMouseTracking(true);
    this->init(800, 600);
}

void Canvas::init(int w, int h)
{
    // 设置固定大小
    this->setFixedSize(w, h);

    // 初始化无按键
    mbutton = Qt::MouseButton::NoButton;

    // 创建画板图片
    m_image = QImage(w, h, QImage::Format_RGBA8888);

    // 使用白色清空画面
    m_image.fill(Qt::white);

    // 初始化画笔颜色
    m_penColor = Qt::black;
}

PenType Canvas::penType() const
{
    return m_penType;
}

// 设置画笔类型
void Canvas::setPenType(const PenType& penType)
{
    m_penType = penType;
}

void Canvas::mousePressEvent(QMouseEvent* event)
{
    if (event->button() == Qt::LeftButton) {
        mbutton = event->button();
        lastpos = mouse;
    }
    else if (event->button() == Qt::RightButton) {
    }
}

void Canvas::mouseReleaseEvent(QMouseEvent* event)
{
    if (event->button() == Qt::LeftButton) {
        // 创建图片
        QPainter painter(&m_image);

        painter.setRenderHints(QPainter::Antialiasing | QPainter::TextAntialiasing | QPainter::SmoothPixmapTransform);

        // 根据画笔类型进行绘制
        switch (m_penType) {
        case PenType::Line:
            painter.drawLine(lastpos, mouse);
            break;
        case PenType::Rectangle:
            painter.drawRect(QRect(lastpos, mouse));
            break;
        case PenType::Ellipse:
            painter.drawEllipse(QRect(lastpos, mouse));
            break;
        case PenType::Triangle:
            painter.drawPolygon(genTriangle(lastpos, mouse));
            break;
        case PenType::Text:
            if (lastpos != mouse) {
                TextInputBox* inputBox = new TextInputBox(this->parentWidget());
                inputBox->setGeometry(makeRect(lastpos, mouse));
                inputBox->show();
                inputBox->setFocus();

                inputBox->setText("输入文字");
                inputBox->selectAll();

                connect(inputBox, SIGNAL(paintText(QRect, QString)), this, SLOT(on_paintText(QRect, QString)));
            }
            break;
        default:
            break;
        }

        this->update();
    }
    else if (event->button() == Qt::RightButton) {
        // 根据画笔类型进行处理
        switch (m_penType) {
        case PenType::Line:
        case PenType::Rectangle:
        case PenType::Ellipse:
        case PenType::Triangle:
            m_penType = PenType::None;
            break;
        case PenType::Text:
            break;
        default:
            break;
        }
    }
    mbutton = Qt::MouseButton::NoButton;
}

// 鼠标移动
void Canvas::mouseMoveEvent(QMouseEvent* event)
{
    mouse = event->pos();

    // 如果鼠标左键按下，并且当前画笔不为空，则开始进行绘制
    if (mbutton == Qt::LeftButton && m_penType != PenType::None) {
        this->update();
    }
}

// 窗口绘制
void Canvas::paintEvent(QPaintEvent*)
{
    QPainter painter(this);

    painter.setRenderHints(QPainter::Antialiasing | QPainter::TextAntialiasing | QPainter::SmoothPixmapTransform);

    painter.drawImage(0, 0, m_image);

    if (mbutton == Qt::LeftButton) {
        // 设置画笔
        painter.setPen(QPen(Qt::blue, 1.0f, Qt::PenStyle::DashLine));
        switch (m_penType) {
        case PenType::Line:
            painter.drawLine(lastpos, mouse);
            break;
        case PenType::Rectangle:
            painter.drawRect(QRect(lastpos, mouse));
            break;
        case PenType::Ellipse:
            painter.drawEllipse(QRect(lastpos, mouse));
            break;
        case PenType::Triangle:
            painter.drawPolygon(genTriangle(lastpos, mouse));
            break;
        case PenType::Text:
            painter.drawRect(QRect(lastpos, mouse));
            break;
        default:
            break;
        }
    }
}

//绘制三角形
QPolygon Canvas::genTriangle(QPoint a, QPoint b)
{

    int x1 = std::min(a.x(), b.x());
    int x2 = std::max(a.x(), b.x());
    int y1 = std::min(a.y(), b.y());
    int y2 = std::max(a.y(), b.y());

    QPolygon polygon;
    polygon.append(QPoint((x1 + x2) / 2, y1));
    polygon.append(QPoint(x2, y2));
    polygon.append(QPoint(x1, y2));

    return polygon;
}

//输入文字
void Canvas::on_paintText(QRect rect, QString str)
{

    QPainter painter(&m_image);

    painter.setRenderHints(QPainter::Antialiasing | QPainter::TextAntialiasing | QPainter::SmoothPixmapTransform);

    painter.setPen(Qt::black);

    painter.drawText(rect, str);

    this->update();
}
