﻿#ifndef CANVAS_H
#define CANVAS_H

#include <QWidget>

// 画笔类型
enum class PenType
{
    None,      // 无
    Line,      // 直线
    Rectangle, // 矩形
    Ellipse,   // 椭圆
    Triangle,  // 三角形
    Text,      // 文字
};


class Canvas : public QWidget//画板类
{
    Q_OBJECT
public:
    explicit Canvas(QWidget* parent = nullptr);

    void init(int w, int h);


    PenType penType() const;                 // 返回画笔类型
    void setPenType(const PenType& penType); // 设置画笔类型

protected:
    void mousePressEvent(QMouseEvent* event);   // 鼠标按下
    void mouseReleaseEvent(QMouseEvent* event); // 鼠标释放
    void mouseMoveEvent(QMouseEvent* event);    // 鼠标移动

    void paintEvent(QPaintEvent* event);        // 进行绘制

public slots:
    void on_paintText(QRect rect, QString str);

private:
    QPoint mouse;            // 当前鼠标位置
    QPoint lastpos;          // 最后鼠标位置
    Qt::MouseButton mbutton; // 鼠标按键

    PenType m_penType;       // 当前画笔类型
    QColor m_penColor;       // 画笔颜色

    QImage m_image;          // 画板的图片

    QPolygon genTriangle(QPoint a, QPoint b);//绘制三角形
};

inline QRect makeRect(QPoint a, QPoint b)
{
    int x1 = std::min(a.x(), b.x());
    int x2 = std::max(a.x(), b.x());
    int y1 = std::min(a.y(), b.y());
    int y2 = std::max(a.y(), b.y());

    return QRect(x1, y1, x2 - x1, y2 - y1);
}

#endif // CANVAS_H
