﻿#ifndef TEXTINPUTBOX_H
#define TEXTINPUTBOX_H

#include <QTextEdit>

class TextInputBox : public QTextEdit
{
    Q_OBJECT
public:
    explicit TextInputBox(QWidget* parent = nullptr);

signals:
    void paintText(QRect rect, QString str);

protected:
    void focusOutEvent(QFocusEvent* event);
};

#endif // TEXTINPUTBOX_H
