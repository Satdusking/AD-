﻿#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QAction>
#include <QKeyEvent>
#include <QMouseEvent>
#include <QPainter>
#include <QTextEdit>

MainWindow::MainWindow(QWidget* parent) :
    QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    this->setMouseTracking(true);

    m_canvas = new Canvas(this);
    ui->scrollArea->setWidget(m_canvas);

    // 新建
    connect(ui->actionFileNew, &QAction::triggered, this, [=](){
        m_canvas->init(800, 600);
    });

    // 打开
    connect(ui->actionFileOpen, &QAction::triggered, this, [=]() {

    });

    // 保存
    connect(ui->actionFileSave, &QAction::triggered, this, [=]() {

    });

    // 关闭
    connect(ui->actionFileClose, &QAction::triggered, this, [=]() {
        this->close();
    });

    // 绘制直线
    connect(ui->actionLine, &QAction::triggered, this, [=]() {
        m_canvas->setPenType(PenType::Line);
    });

    // 绘制矩形
    connect(ui->actionRect, &QAction::triggered, this, [=]() {
        m_canvas->setPenType(PenType::Rectangle);
    });

    // 绘制椭圆
    connect(ui->actionEllipse, &QAction::triggered, this, [=]() {
        m_canvas->setPenType(PenType::Ellipse);
    });

    // 绘制三角形
    connect(ui->actionTriangle, &QAction::triggered, this, [=]() {
        m_canvas->setPenType(PenType::Triangle);
    });

    // 输入文字
    connect(ui->actionText, &QAction::triggered, this, [=]() {
        m_canvas->setPenType(PenType::Text);
    });
}

MainWindow::~MainWindow()
{
    delete ui;
}

// 改变窗口大小
void MainWindow::resizeEvent(QResizeEvent* event)
{
}
