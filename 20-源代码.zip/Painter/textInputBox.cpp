﻿#include "textInputBox.h"

TextInputBox::TextInputBox(QWidget* parent) :
    QTextEdit(parent)
{
    // 透明背景
    this->setStyleSheet("background-color: rgba(255, 255, 255, 0);");
}

void TextInputBox::focusOutEvent(QFocusEvent* event)
{
    emit paintText(this->geometry(), this->toPlainText());

    //删除
    delete this;
}
